# Free-Gen-z
Gen-Z payment style demo side 
